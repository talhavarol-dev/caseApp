//
//  DetailViewController.swift
//  kukaCaseSwift
//
//  Created by Talha Varol on 9.04.2022.
//

import UIKit
import Alamofire
import Kingfisher
class DetailViewController: UIViewController {

   //MARK: -IBOutlet
    
    @IBOutlet weak var driverImageView: UIImageView!
    @IBOutlet weak var ageLabel: UILabel!
    @IBOutlet weak var teamLabel: UILabel!
    
    //MARK: -Properties
    var selectedDriverId: Int?
    
    //MARK: -LifeCycle
    override func viewDidLoad() {
        super.viewDidLoad()
        getDriverDetail()
       
    }
    
    //MARK: -Functions
    // driverDetail urs request .get method
    func getDriverDetail(){
        let url = URL(string: "https://my-json-server.typicode.com/oguzayan/kuka/driverDetail")
        
        let request = AF.request(url!, method: .get)
        request.responseDecodable(of: DriverList.self) { (response) in
          guard let driverList = response.value else { return }
            let driver = driverList.filter { $0.id == self.selectedDriverId }.first
            
            /*
             .first neden kullanıldı?
             verilen bağlatıdan id = 2 ye request atıldığında 2 farklı [] array veriyor.
             .first diyerek elde ettğimiz şey;
             id numarası 2 olan ve .get edebildiğin ilk veriyi göster. 2.3.4. bizim için,
             önemli değil anlamı taşır.
             */
            
            
            self.ageLabel.text = driver?.age?.description ?? ""
            self.teamLabel.text = driver?.team ?? ""
            let urlString = driver?.image ?? ""            // return empty string if value is nil
         
            // KingFisher .get imageView
            
            let url = URL(string: urlString)
            
            self.driverImageView.kf.setImage(with: url)
             
        }
    }


}
