//
//  DriversViewController.swift
//  kukaCaseSwift
//
//  Created by Talha Varol on 9.04.2022.
//

import UIKit
import Alamofire

class DriversViewController: UIViewController {
    //MARK: -IBOutlet
    
    @IBOutlet weak var tableView: UITableView!
    //MARK: -Properties
    var items: [Item] = [] // Driver Model, insert .get items object
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tableView.delegate = self
        tableView.dataSource = self
        // nib is pro identifair
        let nib = UINib(nibName: String(describing: DriversTableViewCell.self), bundle: nil)
        tableView.register(nib, forCellReuseIdentifier: String(describing: DriversTableViewCell.self))
       
        getDrivers()
        
    }
    // MARK: - Functions
    // Get Drivers json "items" object and. sorted point
    func getDrivers(){
        let url = URL(string: "https://my-json-server.typicode.com/oguzayan/kuka/drivers")
        
        let request = AF.request(url!, method: .get)
        request.responseDecodable(of: Drivers.self) { (response) in
          guard let drivers = response.value else { return }
            self.items = drivers.items ??  []
            self.items = self.items.sorted { $0.point > $1.point}
            self.tableView.reloadData()
            
        }
    }
}


//MARK: -Extension
extension DriversViewController: UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 48
    }
    
    
}

extension DriversViewController: UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return items.count
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
       // value assignments cell
        let cell = tableView.dequeueReusableCell(withIdentifier: String(describing: DriversTableViewCell.self), for: indexPath) as! DriversTableViewCell
        let item = items[indexPath.row]
        cell.nameLabel.text = item.name
        cell.pointLabel.text = item.point.description
        cell.didTapped = {                         //Button clousers
            print("button tapped")
            
        }
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let selectedDriver = items[indexPath.row]
        // StoryBoard Segue / selected index value id detail
        let driverDetailStoryBoard = UIStoryboard(name: "DriverDetail", bundle: nil)
        let detailViewController = driverDetailStoryBoard.instantiateViewController(withIdentifier: "DetailViewController") as! DetailViewController
        detailViewController.selectedDriverId = selectedDriver.id
        self.navigationController?.pushViewController(detailViewController, animated: true)
        
        
    }
    
    
    
}

