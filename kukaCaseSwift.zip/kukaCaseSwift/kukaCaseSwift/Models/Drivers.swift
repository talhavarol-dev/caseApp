//
//  Drivers.swift
//  kukaCaseSwift
//
//  Created by Talha Varol on 9.04.2022.
//

import Foundation
// model oluşturmada https://quicktype.io/ kullanılmıştır.
struct Drivers: Codable {
    var items: [Item]?
}

// MARK: - Item
struct Item: Codable {
    let id: Int
    let name: String
    let point: Int
}

